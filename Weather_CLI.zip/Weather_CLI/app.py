import argparse
import pyfiglet
from simple_chalk import chalk
import requests

class WeatherApp:
    API_KEY = "7a9d100dc1d4a5ac458caf5ac8b79a8f"

    BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

    WEATHER_ICONS ={
        # days icons
        "01d":"01d.png",
        "02d":"02d.png",
        "03d":"03d.png",
        "04d":"04d.png",
        "09d":"09d.png",
        "10d":"10d.png",
        "11d":"11d.png",
        "13d":"13d.png",
        "50d":"50d.png",
        
        # night icons
        "01n":"01n.png",
        "02n":"02n.png",
        "03n":"03n.png",
        "04n":"04n.png",
        "09n":"09n.png",
        "10n":"10n.png",
        "11n":"11n.png",
        "13n":"13n.png",
        "50n":"50n.png",
        
    }

    # WEATHER_ICONS ={
    #     # days icons
    #     "01d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\01d.png",
    #     "02d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\02d.png",
    #     "03d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\03d.png",
    #     "04d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\04d.png",
    #     "09d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\09d.png",
    #     "10d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\10d.png",
    #     "11d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\11d.png",
    #     "13d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\13d.png",
    #     "50d":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\50d.png",
        
    #     # night icons
    #     "01n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\01n.png",
    #     "02n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\02n.png",
    #     "03n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\03n.png",
    #     "04n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\04n.png",
    #     "09n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\09n.png",
    #     "10n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\10n.png",
    #     "11n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\11n.png",
    #     "13n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\13n.png",
    #     "50n":"E:\Research\Python\Intro-Programming\Weather_CLI\icons\50n.png",
        
    # }

    # Making APU URL parameters with query parameters

    # We are using argparse library for to parse the command line arguements
    parser = argparse.ArgumentParser(description="Check weather for certain country or city")
    parser.add_argument("country", help="The country/city to check weather for")
    args = parser.parse_args()

    url = f"{BASE_URL}?q={args.country}&appid={API_KEY}&units=metric"

    # Mak API request and parse response using request module
    response = requests.get(url)

    if response.status_code != 200:
        print("Error: Unable to get retrieve weather information")
        exit()
        
    # Parsing the JSON response from the API and extract the weather information
    data = response.json()

    # Get information from response data
    temperature = data["main"]["temp"]
    feels_like = data["main"]["feels_like"]
    description_ = data["weather"][0]["description"]
    icon = data["weather"][0]["icon"] 
    city = data["name"]
    country = data["sys"]["country"]


    # Construct the output with weather icon

    weather_icon = WEATHER_ICONS.get(icon,"")
    output = f"{pyfiglet.figlet_format(city)}, {country}\n\n"
    output += f"{weather_icon} {description_}\n"
    output += f"Temperature: {temperature}°C\n"
    output += f"Feel like: {feels_like}°C\n"


    # Result 
    print(chalk.green(output))



   


# API - KEYS 7a9d100dc1d4a5ac458caf5ac8b79a8f
